<?php
namespace Config;

use PDO;
use PDOException;

class Conexion {
    private static ?PDO $instancia = null;

    private string $host = 'localhost';
    private string $port = '1521';
    private string $serviceName = 'FREEPDB1'; // O el SID de tu base de datos Oracle
    private string $user = 'ironman_db';   // Tu usuario de Oracle
    private string $pass = '901080';   // Tu contraseña de Oracle

    private function __construct() {}

    public static function getInstancia(): PDO {
        if (self::$instancia === null) {
            $conexionAux = new self();
            
            $tns = "(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST={$conexionAux->host})(PORT={$conexionAux->port}))(CONNECT_DATA=(SERVICE_NAME={$conexionAux->serviceName})))";
            $dsn = "oci:dbname=" . $tns . ";charset=UTF8";
            
            $opciones = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_CASE               => PDO::CASE_LOWER
            ];

            try {
                self::$instancia = new PDO($dsn, $conexionAux->user, $conexionAux->pass, $opciones);
            } catch (PDOException $e) {
                throw new PDOException("Error de conexión a Oracle: " . $e->getMessage());
            }
        }
        return self::$instancia;
    }
}