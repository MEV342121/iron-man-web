<?php
// Incluir archivos usando rutas relativas correctas desde 'test-conexiones/'
require_once __DIR__ . '/../config/conexion.php';
require_once __DIR__ . '/../models/Solicitud.php';
require_once __DIR__ . '/../dao/SolicitudDAO.php';

use Dao\SolicitudDAO;

try {
    $solicitudDao = new SolicitudDAO();

    // 1. Probar registro transaccional
    $exito = $solicitudDao->registrarSolicitudConCliente(
        "Juan Pérez",
        "987654321",
        "juan.perez@email.com",
        "Protector de Ventanas",
        "Fabricación e instalación de 3 protectores de fierro para vivienda en Chincha."
    );

    if ($exito) {
        echo "¡Transacción exitosa! Cliente y solicitud registrados en Oracle Database.\n";
    } else {
        echo "Error: La transacción fue revertida (Rollback).\n";
    }

    // 2. Probar recuperación de datos
    $solicitudesPendientes = $solicitudDao->obtenerSolicitudesPorEstado('Pendiente');

    echo "\nSolicitudes Pendientes Recuperadas (" . count($solicitudesPendientes) . "):\n";
    foreach ($solicitudesPendientes as $solicitud) {
        echo "- Cliente: " . $solicitud['nombre_completo'] . 
             " | Estructura: " . $solicitud['tipo_estructura'] . 
             " | Estado: " . $solicitud['estado'] . "\n";
    }

} catch (Exception $e) {
    echo "Excepción capturada: " . $e->getMessage() . "\n";
}