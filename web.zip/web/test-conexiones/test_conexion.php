<?php

// Importar el archivo del modelo
require_once __DIR__ . '/models/Solicitud.php';

// Usar el espacio de nombres (namespace)
use Model\Solicitud;

// Crear una instancia de la clase
$solicitud = new Solicitud(
    idSolicitud: 1,
    idCliente: 100,
    tipoEstructura: 'Especial',
    descripcionRequerimiento: 'Prueba de requerimiento',
    estado: 'Pendiente',
    fechaSolicitud: date('Y-m-d')
);

// Imprimir los datos para verificar
echo "<pre>";
var_dump($solicitud);
echo "</pre>";