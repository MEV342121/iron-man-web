<?php
namespace Model;

/**
 * Clase Solicitud
 * Mapea la tabla 'solicitudes' del esquema de Oracle Database.
 */
class Solicitud {
    public function __construct(
        public ?int $idSolicitud = null,
        public int $idCliente = 0,
        public string $tipoEstructura = '',
        public string $descripcionRequerimiento = '',
        public string $estado = 'Pendiente',
        public ?string $fechaSolicitud = null
    ) {}
}