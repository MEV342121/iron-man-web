<?php
namespace Dao;

use Config\Conexion;
use PDO;
use Exception;
/**
 * Clase SolicitudDAO
 * Encapsula la recuperacion de datos y el control transaccional para la gestion de solicitudes.
 */
class SolicitudDAO {
    private PDO $db;

    public function __construct() {
        // Asignacion de la instancia conexion Singleton
        $this->db = Conexion::getInstancia();
    }

    /**
     * Registra un cliente y su solicitud de cotizacion bajo control transaccional ACID.
     * 
     * @param string $nombreCliente Nombre completo del cliente
     * @param string $telefono Telefono de contacto
     * @param string|null $correo Correo electronico
     * @param string $tipoEstructura Tipo de trabajo solicitado (ej. Techos, Protectores)
     * @param string $descripcion Detalle de las medidas y requerimientos
     * @return bool True si la transaccion se realizo con exito, False si fue revertida
     */
    public function registrarSolicitudConCliente(
        string $nombreCliente, 
        string $telefono, 
        ?string $correo, 
        string $tipoEstructura, 
        string $descripcion
    ): bool {
        try {
            // 1. Inicio de la Transaccion
            $this->db->beginTransaction();

            // 2. Insertar Cliente y recuperar el ID autogenerado en Oracle
            $sqlCliente = "INSERT INTO clientes (nombre_completo, telefono, correo) 
                           VALUES (:nombre, :telefono, :correo) 
                           RETURNING id_cliente INTO :id_cliente";
            
            $stmtCliente = $this->db->prepare($sqlCliente);
            $stmtCliente->bindParam(':nombre', $nombreCliente, PDO::PARAM_STR);
            $stmtCliente->bindParam(':telefono', $telefono, PDO::PARAM_STR);
            $stmtCliente->bindParam(':correo', $correo, PDO::PARAM_STR);
            
            // Variable por referencia para capturar el ID de retorno desde Oracle
            $idCliente = 0;
            $stmtCliente->bindParam(':id_cliente', $idCliente, PDO::PARAM_INT | PDO::PARAM_INPUT_OUTPUT, 32);
            $stmtCliente->execute();

            // 3. Insertar Solicitud vinculando la clave foranea recibida
            $sqlSolicitud = "INSERT INTO solicitudes (id_cliente, tipo_estructura, descripcion_requerimiento) 
                             VALUES (:id_cliente, :tipo, :descripcion)";
            
            $stmtSolicitud = $this->db->prepare($sqlSolicitud);
            $stmtSolicitud->execute([
                ':id_cliente'  => $idCliente,
                ':tipo'        => $tipoEstructura,
                ':descripcion' => $descripcion
            ]);

            // 4. Confirmacion de la Transaccion si ambas consultas fueron exitosas
            $this->db->commit();
            return true;

        } catch (Exception $e) {
            // Reversion total de cambios en caso de fallo
            $this->db->rollBack();
            error_log("Error transaccional en SolicitudDAO: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Recupera el listado de solicitudes filtradas por su estado comercial.
     * 
     * @param string $estado Estado de la solicitud (Pendiente, Cotizado, Aceptado, etc.)
     * @return array Arreglo asociativo con la informacion combinada de clientes y solicitudes
     */
    public function obtenerSolicitudesPorEstado(string $estado): array {
        $sql = "SELECT s.id_solicitud, c.nombre_completo, c.telefono, c.correo,
                       s.tipo_estructura, s.descripcion_requerimiento, s.estado, s.fecha_solicitud 
                FROM solicitudes s
                INNER JOIN clientes c ON s.id_cliente = c.id_cliente
                WHERE s.estado = :estado
                ORDER BY s.fecha_solicitud DESC";
                
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':estado' => $estado]);
        return $stmt->fetchAll();
    }

    /**
     * Actualiza el estado del flujo comercial para una solicitud registrada.
     * 
     * @param int $idSolicitud Identificador de la solicitud
     * @param string $nuevoEstado Nuevo estado a asignar
     * @return bool True si la actualizacion fue exitosa
     */
    public function actualizarEstado(int $idSolicitud, string $nuevoEstado): bool {
        $sql = "UPDATE solicitudes SET estado = :estado WHERE id_solicitud = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':estado' => $nuevoEstado,
            ':id'     => $idSolicitud
        ]);
    }
}